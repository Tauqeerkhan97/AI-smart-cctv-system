from sqlalchemy import Column, Integer, String, DateTime, Float, LargeBinary, Boolean, Text
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()


class Person(Base):
    __tablename__ = 'persons'
    id            = Column(Integer, primary_key=True, autoincrement=True)
    name          = Column(String(120), default='Unknown')
    gender        = Column(String(20),  default='Unknown')
    face_encoding = Column(LargeBinary, nullable=True)
    is_thief      = Column(Boolean, default=False)
    location      = Column(String(200), default='')
    image_path    = Column(String(500), default='')
    detected_at   = Column(DateTime, default=datetime.utcnow)
    notes         = Column(Text, default='')


class MovementLog(Base):
    __tablename__ = 'movement_logs'
    id          = Column(Integer, primary_key=True, autoincrement=True)
    person_id   = Column(Integer, nullable=False)
    track_id    = Column(Integer, nullable=False)
    x_position  = Column(Float)
    y_position  = Column(Float)
    body_angle  = Column(Float, default=0.0)
    direction   = Column(String(50), default='Stationary')
    camera_id   = Column(String(50), default='CAM_01')
    timestamp   = Column(DateTime, default=datetime.utcnow)


class Alert(Base):
    __tablename__ = 'alerts'
    id          = Column(Integer, primary_key=True, autoincrement=True)
    alert_type  = Column(String(50))
    person_id   = Column(Integer, nullable=True)
    person_name = Column(String(120), default='Unknown')
    image_path  = Column(String(500), default='')
    camera_id   = Column(String(50),  default='CAM_01')
    resolved    = Column(Boolean, default=False)
    timestamp   = Column(DateTime, default=datetime.utcnow)


class StudentLog(Base):
    __tablename__ = 'student_logs'
    id         = Column(Integer, primary_key=True, autoincrement=True)
    student_id = Column(Integer, nullable=True)
    name       = Column(String(120), default='Unknown')
    camera_id  = Column(String(50))
    location   = Column(String(200))
    entry_time = Column(DateTime, default=datetime.utcnow)
    exit_time  = Column(DateTime, nullable=True)
    gender     = Column(String(20), default='Unknown')
