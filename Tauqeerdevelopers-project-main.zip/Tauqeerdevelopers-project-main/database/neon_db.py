import pickle
import logging
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from config import NEON_DATABASE_URL
from database.models import Base, Person, MovementLog, Alert, StudentLog

logger = logging.getLogger(__name__)

engine  = create_engine(NEON_DATABASE_URL, pool_pre_ping=True)
Session = sessionmaker(bind=engine)


def init_database():
    Base.metadata.create_all(engine)
    print('[DB] NEON Database ready.')


def save_person(name, gender, face_encoding, is_thief=False, location='', image_path=''):
    session = Session()
    try:
        encoded = pickle.dumps(face_encoding) if face_encoding is not None else None
        person  = Person(name=name, gender=gender, face_encoding=encoded,
                         is_thief=is_thief, location=location, image_path=image_path)
        session.add(person)
        session.commit()
        return person.id
    except Exception as e:
        session.rollback()
        logger.error('save_person: %s', e)
        return -1
    finally:
        session.close()


def get_all_thieves():
    session = Session()
    try:
        rows = session.query(Person).filter_by(is_thief=True).all()
        return [(r.name, pickle.loads(r.face_encoding) if r.face_encoding else None, r.id) for r in rows]
    finally:
        session.close()


def log_movement(person_id, track_id, x, y, angle=0.0, direction='Stationary', camera_id='CAM_01'):
    session = Session()
    try:
        session.add(MovementLog(person_id=person_id, track_id=track_id,
                                x_position=x, y_position=y,
                                body_angle=angle, direction=direction,
                                camera_id=camera_id))
        session.commit()
    except Exception as e:
        session.rollback()
        logger.error('log_movement: %s', e)
    finally:
        session.close()


def save_alert(alert_type, person_id=None, person_name='Unknown', image_path='', camera_id='CAM_01'):
    session = Session()
    try:
        alert = Alert(alert_type=alert_type, person_id=person_id,
                      person_name=person_name, image_path=image_path,
                      camera_id=camera_id)
        session.add(alert)
        session.commit()
        return alert.id
    except Exception as e:
        session.rollback()
        logger.error('save_alert: %s', e)
        return -1
    finally:
        session.close()
