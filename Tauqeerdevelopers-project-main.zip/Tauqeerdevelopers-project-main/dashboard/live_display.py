import cv2
from datetime import datetime


class LiveDisplay:
    """
    Draws a semi-transparent HUD on the frame showing:
      - FPS
      - Total / Male / Female counts
      - Current date-time
      - Camera ID
      - Thief alert banner (when active)
    """

    def __init__(self, camera_id: str = 'CAM_01'):
        self.camera_id    = camera_id
        self.thief_alert  = False
        self.alert_name   = ''

    # ------------------------------------------------------------------
    def set_thief_alert(self, active: bool, name: str = ''):
        self.thief_alert = active
        self.alert_name  = name

    # ------------------------------------------------------------------
    def render(self, frame, fps: float, counts: dict) -> object:
        h, w = frame.shape[:2]

        # --- left panel background ---
        overlay = frame.copy()
        cv2.rectangle(overlay, (0, 0), (280, 130), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.55, frame, 0.45, 0, frame)

        # --- stats text ---
        ts = datetime.now().strftime('%Y-%m-%d  %H:%M:%S')
        lines = [
            (f'Camera : {self.camera_id}',       (200, 200, 200)),
            (f'FPS    : {fps:.1f}',               (0,   255,   0)),
            (f'Total  : {counts.get("total",0)}', (255, 255, 255)),
            (f'Male   : {counts.get("male", 0)}', (255, 140,   0)),
            (f'Female : {counts.get("female",0)}', (220,  80, 255)),
            (ts,                                   (180, 180, 180)),
        ]
        for i, (text, color) in enumerate(lines):
            cv2.putText(frame, text, (8, 20 + i * 20),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.52, color, 1)

        # --- thief alert banner ---
        if self.thief_alert:
            banner_overlay = frame.copy()
            cv2.rectangle(banner_overlay, (0, h - 50), (w, h), (0, 0, 180), -1)
            cv2.addWeighted(banner_overlay, 0.7, frame, 0.3, 0, frame)
            cv2.putText(frame,
                        f'!! THIEF DETECTED: {self.alert_name}  !!',
                        (10, h - 15),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.85, (0, 0, 255), 2)

        return frame
