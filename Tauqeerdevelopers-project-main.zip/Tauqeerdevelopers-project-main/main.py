#!/usr/bin/env python3
"""
Smart CCTV Security System - Main Entry Point

Controls:
  q  - Quit
  s  - Stop alarm
  c  - Manual snapshot
  a  - Add current unknown face to DB as thief
"""

import cv2
import time
import os

from config import (
    CAMERA_INDEX, RTSP_URL,
    FRAME_WIDTH, FRAME_HEIGHT,
    GENDER_CLASSIFY_INTERVAL, FACE_DETECT_INTERVAL,
    CAPTURE_PATH, KNOWN_FACES_DIR, LOGS_DIR,
)
from database.neon_db import init_database, log_movement, save_alert
from detection.person_detector  import PersonDetector
from detection.face_recognizer  import FaceRecognizer
from detection.gender_classifier import GenderClassifier
from detection.pose_estimator   import PoseEstimator
from tracking.movement_tracker  import MovementTracker
from tracking.eye_region        import highlight_eye_region
from alerts.alarm_system        import AlarmSystem
from alerts.whatsapp_notifier   import WhatsAppNotifier
from dashboard.live_display     import LiveDisplay
from utils.image_capture        import capture_image, ensure_dirs
from utils.logger               import get_logger

logger = get_logger('main')


def open_camera():
    src = RTSP_URL if RTSP_URL else CAMERA_INDEX
    cap = cv2.VideoCapture(src)
    cap.set(cv2.CAP_PROP_FRAME_WIDTH,  FRAME_WIDTH)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, FRAME_HEIGHT)
    if not cap.isOpened():
        raise RuntimeError(f'Cannot open camera source: {src}')
    return cap


def main():
    ensure_dirs(CAPTURE_PATH, KNOWN_FACES_DIR, LOGS_DIR, 'assets')

    # ------------------------------------------------------------------ init
    logger.info('Initialising Smart CCTV Security System...')
    init_database()

    detector   = PersonDetector()
    recognizer = FaceRecognizer()
    gender_clf = GenderClassifier()
    pose_est   = PoseEstimator()
    tracker    = MovementTracker()
    alarm      = AlarmSystem()
    notifier   = WhatsAppNotifier()
    hud        = LiveDisplay(camera_id='CAM_01')

    cap         = open_camera()
    frame_no    = 0
    fps         = 0.0
    fps_timer   = time.time()
    counts      = {'total': 0, 'male': 0, 'female': 0}
    genders     = {}          # track_id -> gender string
    last_faces  = []          # face results from last recognition pass
    thief_active = False

    logger.info('System running. Press q=quit  s=stop-alarm  c=capture  a=add-thief')
    print('\n[SYSTEM] Smart CCTV running. Press q / s / c / a')

    while True:
        ret, frame = cap.read()
        if not ret:
            logger.warning('Frame read failed – retrying...')
            time.sleep(0.05)
            continue

        frame_no += 1

        # ---- FPS --------------------------------------------------------
        if frame_no % 30 == 0:
            fps       = 30.0 / max(time.time() - fps_timer, 1e-6)
            fps_timer = time.time()

        # ================================================================
        # 1. PERSON DETECTION & TRACKING
        # ================================================================
        detections = detector.detect_persons(frame)
        counts['total']  = len(detections)
        counts['male']   = 0
        counts['female'] = 0
        thief_active     = False

        for det in detections:
            tid  = det['track_id']
            bbox = det['bbox']
            x1, y1, x2, y2 = bbox
            cx, cy = (x1 + x2) // 2, (y1 + y2) // 2

            # -- movement trail --
            tracker.update(tid, (cx, cy))
            direction = tracker.get_direction(tid)

            # -- gender (every N frames) --
            if frame_no % GENDER_CLASSIFY_INTERVAL == 0:
                g = gender_clf.classify(frame, bbox, tid)
                genders[tid] = g
            gender = genders.get(tid, 'Unknown')
            if gender in ('Man',   'Male'):   counts['male']   += 1
            if gender in ('Woman', 'Female'): counts['female'] += 1

            # -- pose / body angle --
            frame, angle = pose_est.estimate(frame, bbox)

            # -- log movement to DB (every 15 frames) --
            if frame_no % 15 == 0:
                log_movement(person_id=tid, track_id=tid,
                             x=float(cx), y=float(cy),
                             angle=angle, direction=direction)

            # -- draw bounding box --
            frame = detector.draw_box(frame, bbox, tid,
                                      gender=gender,
                                      direction=direction,
                                      angle=angle,
                                      is_thief=False)   # updated below

        # ================================================================
        # 2. FACE RECOGNITION
        # ================================================================
        if frame_no % FACE_DETECT_INTERVAL == 0:
            last_faces = recognizer.recognize(frame)

        for face in last_faces:
            loc      = face['location']
            name     = face['name']
            is_thief = face['is_thief']

            frame = recognizer.draw_face(frame, loc, name, is_thief)

            if is_thief:
                thief_active = True
                frame = highlight_eye_region(frame, loc)

                # -- alarm --
                alarm.trigger()

                # -- capture snapshot --
                img_path = capture_image(frame, label='THIEF', person_id=name)

                # -- WhatsApp --
                notifier.send_thief_alert(person_name=name,
                                          location='CAM_01',
                                          image_path=img_path)

                # -- DB alert --
                save_alert(alert_type='thief', person_name=name,
                           image_path=img_path, camera_id='CAM_01')

        # ================================================================
        # 3. MOVEMENT TRAILS
        # ================================================================
        frame = tracker.draw_trails(frame)

        # ================================================================
        # 4. HUD OVERLAY
        # ================================================================
        hud.set_thief_alert(thief_active,
                            name=last_faces[0]['name'] if last_faces and thief_active else '')
        frame = hud.render(frame, fps, counts)

        # ================================================================
        # 5. DISPLAY
        # ================================================================
        cv2.imshow('Smart CCTV Security System', frame)

        # ================================================================
        # 6. KEYBOARD CONTROLS
        # ================================================================
        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            logger.info('Quit requested.')
            break
        elif key == ord('s'):
            alarm.stop()
        elif key == ord('c'):
            capture_image(frame, label='manual')
        elif key == ord('a'):
            # Add first unknown face as thief
            for face in last_faces:
                if face['name'] == 'Unknown':
                    from database.neon_db import save_person
                    pid = save_person(
                        name='Suspect', gender='Unknown',
                        face_encoding=face['encoding'],
                        is_thief=True, location='CAM_01'
                    )
                    logger.info('Added unknown face as thief, DB id=%s', pid)
                    print(f'[DB] Unknown face saved as thief (id={pid})')
                    recognizer._load_thieves_from_db()   # hot-reload
                    break

    # ---- cleanup --------------------------------------------------------
    cap.release()
    cv2.destroyAllWindows()
    alarm.stop()
    logger.info('System stopped.')
    print('[SYSTEM] Stopped.')


if __name__ == '__main__':
    main()
