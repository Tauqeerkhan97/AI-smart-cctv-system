import time
import os
from datetime import datetime

try:
    from twilio.rest import Client
    TWILIO_AVAILABLE = True
except ImportError:
    TWILIO_AVAILABLE = False

from config import (
    TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN,
    TWILIO_WHATSAPP_FROM, WHATSAPP_TO
)


class WhatsAppNotifier:
    def __init__(self):
        self._last_sent = 0
        self._cooldown  = 30   # seconds between messages
        if TWILIO_AVAILABLE and TWILIO_ACCOUNT_SID:
            self._client = Client(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN)
            print('[WhatsApp] Twilio client ready.')
        else:
            self._client = None
            print('[WhatsApp] Twilio not configured – alerts will be printed only.')

    # ------------------------------------------------------------------
    def send(self, message: str, media_url: str = None):
        now = time.time()
        if now - self._last_sent < self._cooldown:
            return
        self._last_sent = now

        print(f'[WhatsApp] {message}')
        if self._client is None:
            return

        try:
            params = {
                'from_': TWILIO_WHATSAPP_FROM,
                'to':    WHATSAPP_TO,
                'body':  message,
            }
            if media_url:
                params['media_url'] = [media_url]
            self._client.messages.create(**params)
        except Exception as e:
            print(f'[WhatsApp] Send failed: {e}')

    # ------------------------------------------------------------------
    def send_thief_alert(self, person_name: str, location: str = 'Unknown', image_path: str = ''):
        ts  = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        msg = (
            f'SECURITY ALERT\n'
            f'THIEF DETECTED!\n'
            f'Name/ID : {person_name}\n'
            f'Location: {location}\n'
            f'Time    : {ts}\n'
            f'Check live feed immediately!'
        )
        self.send(msg)

    def send_crowd_alert(self, count: int, location: str = 'Unknown'):
        ts  = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        msg = (
            f'CROWD ALERT\n'
            f'People count: {count}\n'
            f'Location    : {location}\n'
            f'Time        : {ts}'
        )
        self.send(msg)
