import threading
import time
import os

try:
    import pygame
    pygame.mixer.init()
    PYGAME_AVAILABLE = True
except Exception:
    PYGAME_AVAILABLE = False

from config import ALARM_SOUND_PATH, ALARM_COOLDOWN


class AlarmSystem:
    def __init__(self):
        self.is_active       = False
        self._thread         = None
        self._last_triggered = 0
        print('[Alarm] AlarmSystem ready.')

    # ------------------------------------------------------------------
    def trigger(self):
        now = time.time()
        if self.is_active or (now - self._last_triggered) < ALARM_COOLDOWN:
            return
        self.is_active       = True
        self._last_triggered = now
        print('[Alarm] ALARM TRIGGERED!')
        self._thread = threading.Thread(target=self._play, daemon=True)
        self._thread.start()

    def _play(self):
        if PYGAME_AVAILABLE and os.path.exists(ALARM_SOUND_PATH):
            pygame.mixer.music.load(ALARM_SOUND_PATH)
            pygame.mixer.music.play(-1)
            while self.is_active:
                time.sleep(0.1)
            pygame.mixer.music.stop()
        else:
            # Fallback: terminal beep loop
            while self.is_active:
                print('\a', end='', flush=True)
                time.sleep(1)

    def stop(self):
        self.is_active = False
        print('[Alarm] Alarm stopped.')
