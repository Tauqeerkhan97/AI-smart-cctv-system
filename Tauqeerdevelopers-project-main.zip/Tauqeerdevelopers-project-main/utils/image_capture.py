import os
import cv2
from datetime import datetime
from config import CAPTURE_PATH

os.makedirs(CAPTURE_PATH, exist_ok=True)


def capture_image(frame, label: str = 'capture', person_id: str = 'unknown') -> str:
    """
    Save a JPEG snapshot and return the file path.
    Filename format: captures/<label>_<person_id>_<timestamp>.jpg
    """
    ts       = datetime.now().strftime('%Y%m%d_%H%M%S_%f')
    filename = f'{label}_{person_id}_{ts}.jpg'
    path     = os.path.join(CAPTURE_PATH, filename)
    cv2.imwrite(path, frame)
    print(f'[Capture] Saved: {path}')
    return path


def ensure_dirs(*dirs):
    """Create directories if they do not exist."""
    for d in dirs:
        os.makedirs(d, exist_ok=True)
