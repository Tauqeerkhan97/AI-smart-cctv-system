import cv2


def highlight_eye_region(frame, face_location):
    """
    Draw a semi-transparent neon-green rectangle over the eye area
    of a detected face to help identify a thief.

    face_location: (top, right, bottom, left) in pixel coords.
    """
    top, right, bottom, left = face_location
    face_h = bottom - top

    eye_top    = top + int(face_h * 0.25)
    eye_bottom = top + int(face_h * 0.55)

    overlay = frame.copy()
    cv2.rectangle(overlay, (left, eye_top), (right, eye_bottom), (0, 255, 0), -1)
    cv2.addWeighted(overlay, 0.28, frame, 0.72, 0, frame)
    cv2.rectangle(frame, (left, eye_top), (right, eye_bottom), (0, 255, 0), 2)
    cv2.putText(frame, 'EYE REGION',
                (left, eye_top - 5),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1)
    return frame
