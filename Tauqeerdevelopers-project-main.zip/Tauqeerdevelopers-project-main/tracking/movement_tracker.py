import cv2
import numpy as np
from collections import defaultdict, deque


class MovementTracker:
    def __init__(self, max_trail=40):
        self._trails    = defaultdict(lambda: deque(maxlen=max_trail))
        self._colors    = {}

    # ------------------------------------------------------------------
    def update(self, track_id, center):
        self._trails[track_id].append(center)
        if track_id not in self._colors:
            rng = np.random.default_rng(track_id)
            self._colors[track_id] = tuple(int(c) for c in rng.integers(80, 255, 3))

    # ------------------------------------------------------------------
    def draw_trails(self, frame):
        for tid, trail in self._trails.items():
            pts   = list(trail)
            color = self._colors.get(tid, (0, 255, 255))
            for i in range(1, len(pts)):
                alpha = i / len(pts)
                thick = max(1, int(3 * alpha))
                cv2.line(frame, pts[i - 1], pts[i], color, thick)
            if pts:
                cv2.circle(frame, pts[-1], 5, color, -1)
        return frame

    # ------------------------------------------------------------------
    def get_direction(self, track_id):
        pts = list(self._trails[track_id])
        if len(pts) < 2:
            return 'Stationary'
        look_back = min(5, len(pts) - 1)
        dx = pts[-1][0] - pts[-1 - look_back][0]
        dy = pts[-1][1] - pts[-1 - look_back][1]
        if abs(dx) < 5 and abs(dy) < 5:
            return 'Stationary'
        if abs(dx) >= abs(dy):
            return 'Moving Right' if dx > 0 else 'Moving Left'
        return 'Moving Down' if dy > 0 else 'Moving Up'

    # ------------------------------------------------------------------
    def remove(self, track_id):
        self._trails.pop(track_id, None)
        self._colors.pop(track_id, None)
