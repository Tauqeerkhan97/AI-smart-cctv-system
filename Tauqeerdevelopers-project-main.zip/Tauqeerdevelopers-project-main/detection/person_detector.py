import cv2
from ultralytics import YOLO
from config import YOLO_MODEL, CONFIDENCE_THRESHOLD


class PersonDetector:
    def __init__(self):
        self.model = YOLO(YOLO_MODEL)
        print('[Detector] YOLOv8 model loaded.')

    def detect_persons(self, frame):
        """
        Returns list of dicts:
          { 'bbox': (x1,y1,x2,y2), 'confidence': float, 'track_id': int }
        """
        results = self.model.track(frame, persist=True, classes=[0], verbose=False)
        detections = []

        if results and results[0].boxes is not None:
            for box in results[0].boxes:
                conf = float(box.conf[0])
                if conf < CONFIDENCE_THRESHOLD:
                    continue
                x1, y1, x2, y2 = map(int, box.xyxy[0])
                tid = int(box.id[0]) if box.id is not None else -1
                detections.append({'bbox': (x1, y1, x2, y2),
                                   'confidence': conf,
                                   'track_id': tid})
        return detections

    @staticmethod
    def draw_box(frame, bbox, track_id, gender='Unknown', direction='', angle=0.0, is_thief=False):
        x1, y1, x2, y2 = bbox
        if is_thief:
            color = (0, 0, 255)
            label = f'!! THIEF ID:{track_id}'
        elif gender in ('Man', 'Male'):
            color = (255, 100, 0)
            label = f'Male ID:{track_id}'
        elif gender in ('Woman', 'Female'):
            color = (180, 0, 255)
            label = f'Female ID:{track_id}'
        else:
            color = (0, 200, 200)
            label = f'ID:{track_id}'

        cv2.rectangle(frame, (x1, y1), (x2, y2), color, 2)
        cv2.putText(frame, label,      (x1, y1 - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.55, color, 2)
        cv2.putText(frame, direction,  (x1, y2 + 18), cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 255), 1)
        cv2.putText(frame, f'Angle:{angle:.1f}deg', (x1, y2 + 34),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 0), 1)
        return frame
