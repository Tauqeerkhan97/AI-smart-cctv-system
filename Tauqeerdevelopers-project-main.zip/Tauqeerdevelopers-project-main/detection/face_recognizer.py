import os
import pickle
import numpy as np
import cv2
import face_recognition
from config import KNOWN_FACES_DIR, FACE_RECOGNITION_TOLERANCE
from database.neon_db import get_all_thieves


class FaceRecognizer:
    def __init__(self):
        self.known_encodings = []
        self.known_names     = []
        self.known_flags     = []   # True = thief
        self._load_from_folder()
        self._load_thieves_from_db()
        print(f'[FaceRecognizer] {len(self.known_encodings)} face(s) loaded.')

    # ------------------------------------------------------------------
    def _load_from_folder(self):
        os.makedirs(KNOWN_FACES_DIR, exist_ok=True)
        for fname in os.listdir(KNOWN_FACES_DIR):
            if not fname.lower().endswith(('.jpg', '.jpeg', '.png')):
                continue
            path = os.path.join(KNOWN_FACES_DIR, fname)
            img  = face_recognition.load_image_file(path)
            encs = face_recognition.face_encodings(img)
            if encs:
                name     = os.path.splitext(fname)[0]
                is_thief = name.upper().startswith('THIEF_')
                self.known_encodings.append(encs[0])
                self.known_names.append(name)
                self.known_flags.append(is_thief)

    def _load_thieves_from_db(self):
        for name, enc, _ in get_all_thieves():
            if enc is not None:
                self.known_encodings.append(enc)
                self.known_names.append(name)
                self.known_flags.append(True)

    # ------------------------------------------------------------------
    def recognize(self, frame):
        """
        Returns list of dicts:
          { 'location':(top,right,bottom,left), 'name':str,
            'is_thief':bool, 'encoding': ndarray }
        """
        small  = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)
        rgb    = cv2.cvtColor(small, cv2.COLOR_BGR2RGB)
        locs   = face_recognition.face_locations(rgb)
        encs   = face_recognition.face_encodings(rgb, locs)

        results = []
        for (top, right, bottom, left), enc in zip(locs, encs):
            top, right, bottom, left = top*4, right*4, bottom*4, left*4
            name, is_thief = 'Unknown', False

            if self.known_encodings:
                dists   = face_recognition.face_distance(self.known_encodings, enc)
                best    = int(np.argmin(dists))
                if dists[best] <= FACE_RECOGNITION_TOLERANCE:
                    name     = self.known_names[best]
                    is_thief = self.known_flags[best]

            results.append({'location': (top, right, bottom, left),
                            'name': name, 'is_thief': is_thief,
                            'encoding': enc})
        return results

    # ------------------------------------------------------------------
    @staticmethod
    def draw_face(frame, location, name, is_thief):
        top, right, bottom, left = location
        color = (0, 0, 255) if is_thief else (0, 255, 0)
        cv2.rectangle(frame, (left, top), (right, bottom), color, 2)
        label = f'THIEF: {name}' if is_thief else name
        cv2.putText(frame, label, (left, top - 8),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, color, 2)
        return frame

    @staticmethod
    def highlight_eye_region(frame, location):
        """Draw neon-green eye-area box to help identify thief."""
        top, right, bottom, left = location
        h = bottom - top
        eye_top    = top + int(h * 0.25)
        eye_bottom = top + int(h * 0.55)

        overlay = frame.copy()
        cv2.rectangle(overlay, (left, eye_top), (right, eye_bottom), (0, 255, 0), -1)
        cv2.addWeighted(overlay, 0.25, frame, 0.75, 0, frame)
        cv2.rectangle(frame, (left, eye_top), (right, eye_bottom), (0, 255, 0), 2)
        cv2.putText(frame, 'EYE REGION', (left, eye_top - 5),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 0), 1)
        return frame
