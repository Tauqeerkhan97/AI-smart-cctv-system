import cv2
from deepface import DeepFace


class GenderClassifier:
    def __init__(self):
        self._cache = {}   # track_id -> gender string

    def classify(self, frame, bbox, track_id):
        if track_id in self._cache:
            return self._cache[track_id]

        x1, y1, x2, y2 = bbox
        roi = frame[y1:y2, x1:x2]
        if roi.size == 0:
            return 'Unknown'

        try:
            res    = DeepFace.analyze(roi, actions=['gender'],
                                      enforce_detection=False, silent=True)
            gender = res[0]['dominant_gender']   # 'Man' or 'Woman'
            self._cache[track_id] = gender
            return gender
        except Exception:
            return 'Unknown'

    def clear_cache(self):
        self._cache.clear()
