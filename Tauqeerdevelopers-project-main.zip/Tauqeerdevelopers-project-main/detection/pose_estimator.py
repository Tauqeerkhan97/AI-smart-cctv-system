import math
import cv2
import mediapipe as mp


class PoseEstimator:
    def __init__(self):
        self._mp_pose = mp.solutions.pose
        self._pose    = self._mp_pose.Pose(
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        self._draw    = mp.solutions.drawing_utils
        print('[PoseEstimator] MediaPipe Pose ready.')

    def estimate(self, frame, bbox):
        """
        Returns (annotated_frame, body_angle_degrees).
        Draws skeleton inside the bounding box.
        """
        x1, y1, x2, y2 = bbox
        roi = frame[y1:y2, x1:x2]
        if roi.size == 0:
            return frame, 0.0

        rgb     = cv2.cvtColor(roi, cv2.COLOR_BGR2RGB)
        results = self._pose.process(rgb)
        angle   = 0.0

        if results.pose_landmarks:
            lm  = results.pose_landmarks.landmark
            PL  = self._mp_pose.PoseLandmark
            ls  = lm[PL.LEFT_SHOULDER]
            rs  = lm[PL.RIGHT_SHOULDER]
            dx  = rs.x - ls.x
            dy  = rs.y - ls.y
            angle = math.degrees(math.atan2(dy, dx))

            self._draw.draw_landmarks(
                roi, results.pose_landmarks,
                self._mp_pose.POSE_CONNECTIONS
            )
            frame[y1:y2, x1:x2] = roi

        return frame, angle
