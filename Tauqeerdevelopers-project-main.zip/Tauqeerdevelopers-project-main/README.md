# 🔒 Smart CCTV Security System

AI-powered security system with face recognition, thief detection, WhatsApp alerts, and real-time monitoring.

## Features
- 👤 Person Detection & Tracking (YOLOv8)
- 🧑‍🤝‍🧑 Male/Female Classification (DeepFace)
- 🔍 Face Recognition (NEON Database)
- 🚨 Auto Alarm on Thief Detection
- 📱 WhatsApp Notifications (Twilio)
- 🦴 Body Pose & Angle Estimation (MediaPipe)
- 🛤️ Movement Trail Tracking
- 👁️ Eye Region Highlighting
- 📊 People Counting per Camera
- 🗄️ NEON PostgreSQL Database

## Setup

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Configure Environment
```bash
cp .env.example .env
# Edit .env with your credentials
```

### 3. NEON Database
1. Go to https://neon.tech and create free account
2. Create new project
3. Copy connection string to .env

### 4. Twilio WhatsApp
1. Go to https://twilio.com and create account
2. Activate WhatsApp Sandbox
3. Add Account SID and Auth Token to .env

### 5. Add Known Faces
```
known_faces/
├── person_name.jpg        # Normal person
└── THIEF_suspect.jpg      # Known thief (THIEF_ prefix)
```

### 6. Run System
```bash
python main.py
```

## Controls
- `q` - Quit system
- `s` - Stop alarm
- `c` - Manual capture
- `a` - Add current face to database

## Project Structure
```
smart_cctv/
├── main.py
├── config.py
├── database/
│   ├── neon_db.py
│   └── models.py
├── detection/
│   ├── person_detector.py
│   ├── face_recognizer.py
│   ├── gender_classifier.py
│   └── pose_estimator.py
├── tracking/
│   ├── movement_tracker.py
│   └── eye_region.py
├── alerts/
│   ├── alarm_system.py
│   └── whatsapp_notifier.py
├── dashboard/
│   └── live_display.py
└── utils/
    └── image_capture.py
```
